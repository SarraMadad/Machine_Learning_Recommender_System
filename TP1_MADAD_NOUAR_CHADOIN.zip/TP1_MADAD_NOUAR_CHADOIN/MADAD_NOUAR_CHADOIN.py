##############################################
################## Packages ##################
##############################################

from sklearn import datasets
from pylab import *
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
#from sklearn.neighbors import KNeighborsClassifier
from sklearn import neighbors
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn import datasets
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

##############################################
################# 1. Données #################
##############################################

# Charger la base de données iris :
iris = datasets.load_iris() 

"""
Préciser les dimensions : nombre de descripteurs, 
nombre d’exemples (fonction shape) et le nombre de 
classes de cette base de données.
"""

iris.data.shape # Il y a 4 variables et 150 observations (150, 4)
iris.feature_names # Non des variables ['sepal length (cm)',
                                       # 'sepal width (cm)',
                                       # 'petal length (cm)',
                                       # 'petal width (cm)']
                                       # 4 descripteurs
iris.target_names # Nom des espèces de fleurs :
                  # array(['setosa', 'versicolor', 'virginica'], dtype='<U10')
len(iris.target_names) # 3
# Il y a donc 3 classes : 'setosa', 'versicolor', 'virginica'
# Autre commande qui fait la même chose list(iris.target_names)
# L'échantillons par classe est de 50 observations
# Le total des échantillons 150
# Dimensionnalité 4

# On va manipuler un data frame
df = pd.DataFrame(data=iris.data, columns=iris.feature_names)
df['species'] = iris.target 
df.head() # Afficher l'entête du data frame
df.describe() # Resumé de toutes les variables
len(df.columns) # Nombre de descripteurs

#################################################################
################# 2. Analyse monodimensionnelle #################
#################################################################

"""
Analyser successivement les 4 descripteurs (d1, d2, d3, d4) 
expliquant les données :
"""

"""
1) Calculer la moyenne et la variance de chaque descripteur. 
Choisir correctement le nombre de chiffres significatifs.
"""

round(df.mean(),2) # sepal length (cm)    5.84
                   # sepal width (cm)     3.06
                   # petal length (cm)    3.76
                   # petal width (cm)     1.20
                   # species              1.00
                   # dtype: float64

round(df.var(),2)  # sepal length (cm)    0.69
                   # sepal width (cm)     0.19
                   # petal length (cm)    3.12
                   # petal width (cm)     0.58
                   # species              0.67
                   # dtype: float64

"""
2) Commenter ces résultats : pour faire de la classification, 
quel est le « meilleure descripteur » ? Et le « moins bon » ? 
Expliquer.
"""

"""
Voir les explications dans le rapport.
"""

#############################################################
################# 3. Analyse conditionnelle #################
#############################################################

"""
Analyser chaque descripteur en fonction de (conditionnellement à) 
sa classe :
"""

"""
1) Calculer les moyennes et variances conditionnelles (intra-classe) 
de chaque descripteur.
"""

df1 = df[df["species"]==0]
df2 = df[df["species"]==1]
df3 = df[df["species"]==2]

# Moyennes conditionnelles (intra-classe) 
df1.mean() # sepal length (cm)    5.006
           # sepal width (cm)     3.428
           # petal length (cm)    1.462
           # petal width (cm)     0.246
           # species              0.000
           # dtype: float64
           
df2.mean() # sepal length (cm)    5.936
           # sepal width (cm)     2.770
           # petal length (cm)    4.260
           # petal width (cm)     1.326
           # species              1.000 
           # dtype: float64
           
df3.mean() # sepal length (cm)    6.588
           # sepal width (cm)     2.974
           # petal length (cm)    5.552
           # petal width (cm)     2.026
           # species              2.000
           # dtype: float64

# Variances conditionnelles (intra-classe) 
df1.var() # sepal length (cm)    0.124249
          # sepal width (cm)     0.143690
          # petal length (cm)    0.030159
          # petal width (cm)     0.011106
          # species              0.000000
          # dtype: float64

df2.var() # sepal length (cm)    0.266433
          # sepal width (cm)     0.098469
          # petal length (cm)    0.220816
          # petal width (cm)     0.039106
          # species              0.000000
          # dtype: float64

df3.var() # sepal length (cm)    0.404343
          # sepal width (cm)     0.104004
          # petal length (cm)    0.304588
          # petal width (cm)     0.075433
          # species              0.000000
          # dtype: float64

"""
2) Utiliser le théorème de la variance totale (voir page suivante) 
pour calculer les variances interclasses de chaque descripteur.
"""
varpetall1 = df1['petal length (cm)'].var() # 0.030159183673469397
varpetall2 = df2['petal length (cm)'].var() # 0.22081632653061237
varpetall3 = df3['petal length (cm)'].var() # 0.304587755102041

varpetalw1 = df1['petal width (cm)'].var()  # 0.0111061224489796
varpetalw2 = df2['petal width (cm)'].var()  # 0.039106122448979576
varpetalw3 = df3['petal width (cm)'].var()  # 0.07543265306122447

varsepall1 = df1['sepal length (cm)'].var() # 0.12424897959183666
varsepall2 = df2['sepal length (cm)'].var() # 0.2664326530612246
varsepall3 = df3['sepal length (cm)'].var() # 0.40434285714285706

varsepalw1 = df1['sepal width (cm)'].var()  # 0.14368979591836734
varsepalw2 = df2['sepal width (cm)'].var()  # 0.09846938775510206
varsepalw3 = df3['sepal width (cm)'].var()  # 0.10400408163265312

varpetallg = df['petal length (cm)'].var()  # 3.1162778523489942
varpetalwg = df['petal width (cm)'].var()   # 0.5810062639821029
varsepallg = df['sepal length (cm)'].var()  # 0.6856935123042505
varsepalwg = df['sepal width (cm)'].var()   # 0.1899794183445188

varinterpetall = round(varpetallg - (1/3)*(varpetall1+varpetall2+varpetall3),2) # 2.93
varinterpetalw = round(varpetalwg - (1/3)*(varpetalw1+varpetalw2+varpetalw3),2) # 0.54
varintersepall = round(varsepallg - (1/3)*(varsepall1+varsepall2+varsepall3),2) # 0.42
varintersepalw = round(varsepalwg - (1/3)*(varsepalw1+varsepalw2+varsepalw3),2) # 0.07

#AUTRE FACON DE FAIRE /!\

#Descripteur 1 d1
varinterd1 = round(df["sepal length (cm)"].var() - ((df1["sepal length (cm)"].var() + df2["sepal length (cm)"].var() + df3["sepal length (cm)"].var())/3),2)
varinterd1

#Descripteur 2 d2
varinterd2 = round(df["sepal width (cm)"].var() - ((df1["sepal width (cm)"].var() + df2["sepal width (cm)"].var() + df3["sepal width (cm)"].var())/3),2)
varinterd2

#Descripteur 3 d3
varinterd3 = round(df["petal length (cm)"].var() - ((df1["petal length (cm)"].var() + df2["petal length (cm)"].var() + df3["petal length (cm)"].var())/3),2)
varinterd3

#Descripteur 4 d4
varinterd4 = round(df["petal width (cm)"].var() - ((df1["petal width (cm)"].var() + df2["petal width (cm)"].var() + df3["petal width (cm)"].var())/3),2)
varinterd4

"""
3) Afficher chaque descripteur dans un graphe 
(abscisse : valeur du descripteur, ordonnée : classe).
"""
# Histogramme des 3 classes en fonction des descripteurs
plt.subplot(1,3,1)
plt.hist(df1)
plt.legend(['sepal length (cm)','sepal width (cm)', 'petal length (cm)','petal width (cm)'])

plt.subplot(1,3,2)
plt.hist(df2)
plt.legend(['sepal length (cm)','sepal width (cm)', 'petal length (cm)','petal width (cm)'])

plt.subplot(1,3,3)
plt.hist(df3)
plt.legend(['sepal length (cm)','sepal width (cm)', 'petal length (cm)','petal width (cm)'])

plt.title("Histogramme des 3 classes en fonction des descripteurs")
plt.show()

"""
4) Commenter ces résultats : pour faire de la classification, 
quel est le « meilleure descripteur » ? Et le « moins bon » ? 
Expliquer.
"""

"""
Voir les explications dans le rapport.
"""

#############################################################
################ 4. Analyse bidimensionnelle ################
#############################################################

"""
Pour les paires de descripteurs (d1=1, d2=2) et (d1=2, d2=4) :
"""

"""
1) Afficher les données et leurs moyennes dans le plan (d1, d2).
"""
sns.lmplot(x='sepal length (cm)', y='sepal width (cm)', data=df, hue="species", fit_reg=False, legend=False)
plt.plot(df["sepal length (cm)"].mean(),df["sepal width (cm)"].mean(), marker="o", color="black")
plt.legend(['setosa', 'versicolor', 'virginica'])
plt.title("Nuage de point de la largeur petal en fonction de la largeur sepal")
plt.show()

sns.lmplot(x='petal length (cm)', y='petal width (cm)', data=df, hue="species", fit_reg=False, legend=False)
plt.plot(df["petal length (cm)"].mean(),df["petal width (cm)"].mean(), marker="o", color="black")
plt.legend(['setosa', 'versicolor', 'virginica'])
plt.title("Nuage de point de la longueur petal en fonction de la longueur sepal")
plt.show()         
"""
2) Calculer les matrices de variance/covariance conditionnellement 
aux classes. Comprendre ces matrices en observant la distribution 
des données.
"""

df.cov()
df.corr(method='pearson')

"""
3) Déterminer les frontières de décision si l’on utilise l’algorithme 
nearest-mean pour faire la classification (utiliser la fonction knn 
codée pendant le datacamp).
"""
cmap = ListedColormap (['#FF0000', '#00FF00', '#0000FF'])

irisData = load_iris()

X = irisData.data #données des 4 descripteurs
y = irisData.target #classes


# on divise en set d'entraînement et de tests
#test_size = 0.2 <=> train_size = 0.8 ===> + d'entraînement que de tests
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2)

#on peut voir à quoi ressemble nos données d'entraînement (0.8*150 = 120)
print(X_train, shape) #120 observations avec chacune 4 descripteurs
print(y_train, shape) #120 observations => label de chaque observations

#les premières données d'entraînement
print(X_train[0], shape)
print(y_train[0], shape)

#on peut faire un nuage de points des 2 premiers descripteurs avec 1 classe = 1 couleur
plt.figure
plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap, edgecolor ='k', s=20)
plt.show()

#on crée un classificateur avec k = 3
model = neighbors.KNeighborsClassifier(n_neighbors=3)
#knn = KNeighborsClassifier(n_neighbors=11)

#on ajuste le modèle avec nos données et nos labels d'entraînement
model.fit(X_train, y_train)
#knn.fit(X_train, y_train)

#on veut prédire des labels sur nos données de test
#print(knn.predict(X_test))
predictions = model.predict(X_test)
predictions

#pourcentage d'erreur du modèle (on peut changer cas pour changer ce % et dc améliorer la performance)
#combien de nos prédictions sont correctement classées ?
#en changeant le k on peut changer ce score
#plusieurs méthodes

#methode 1
1 - model.score(X_test, y_test)
#methode 2
acc = np.sum(predictions == y_test)/len(y_test)
print(acc)
#methode 3
model.score(X_test, y_test)

#on peut boucler afin de trouver le meilleur k pour notre classificateur
errors = []
for k in range(2,15):
    model = neighbors.KNeighborsClassifier(n_neighbors=k)
    errors.append(100*(1 - model.fit(X_train, y_train).score(X_test, y_test)))
plt.plot(range(2,15), errors, 'o-')
plt.show()

#enfin, on peut dessiner les frontières/régions de décisions
#on exprime ces régions en fonction de 2 descripteurs qu'on peut tourner
import numpy as np
import pylab as pl
from sklearn import neighbors, datasets

#on importe nos données
iris = datasets.load_iris()
X = iris.data[:, :2] #on prend l'ensemble des obs mais on utilise 2 descripteurs 
Y = iris.target
n_neighbors = 3 #nombre de k voisins pris : hyperparamètre
h = .02 #taille du pas du quadrillage

#on crée des map de couleur
cmap_light = ListedColormap(["orange", "cyan", "cornflowerblue"])
cmap_bold = ["darkorange", "c", "darkblue"]

#on crée un classificateur
knn = neighbors.KNeighborsClassifier(n_neighbors)

#on intègre les données dans notre classificateur
knn.fit(X, Y)

#on met les limites de décisions avec une couleur pour chaque classe
x_min, x_max = X[:,0].min() - .5, X[:,0].max() + .2 #min et max du descripteur 1 avec précision de .2
y_min, y_max = X[:,1].min() - .5, X[:,1].max() + .2 #min et max du descripteur 1 avec précision de .2
xx, yy = np.meshgrid(np.arange(x_min, x_max, h), np.arange(y_min, y_max, h))


#on intègre les précisions du modèle
Z = knn.predict(np.c_[xx.ravel(), yy.ravel()])


#on met les résultats de préduction du modèle dans un plot de couleur
Z = Z.reshape(xx.shape)
plt.figure(figsize=(8, 6))
plt.contourf(xx, yy, Z, cmap=cmap_light)

#on plot les données d'entraînements
sns.scatterplot(x=X[:, 0], y=X[:, 1], hue=iris.target_names[y], palette=cmap_bold, alpha=1.0, edgecolor="black",)

pl.xlim(xx.min(), xx.max())
pl.ylim(yy.min(), yy.max())
pl.xticks(())
pl.yticks(())
plt.title("3-Class classification (k = %i)" % (n_neighbors))
plt.xlabel(iris.feature_names[0])
plt.ylabel(iris.feature_names[1])

pl.show()